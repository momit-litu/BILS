<div class="panel panel-default border-none">
	<div class="panel-heading">
		<i class=" fa fa-file-text "></i>
		Survey
		<div class="panel-tools">			
			<a class="btn btn-xs btn-link panel-refresh" href="#" onclick="pageLoad('survey')">
				<i class="fa fa-refresh"></i>
			</a>
		</div>
	</div>
	<div class="panel-body panel-scroll ps-container ps-active-y fixed-panel">
		<div class="col-sm-12 page-error">
			<h3>Under Construction</h3>
		</div>
	</div>
</div>

	
<script src="{{-- asset('assets/js/bils/admin/user.js')--}}"></script>
<script>
$(document).ready(function(){
	alert("survey")
});
</script>


